<?php get_header(); ?>
<main class="wrapper" id="wrapper">
<?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>