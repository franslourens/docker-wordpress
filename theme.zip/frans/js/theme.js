$.noConflict();
jQuery(function ($) {
    'use strict';
    $(window).ready(function () {
        setTimeout(function () {
            $('#spinner').fadeOut('slow', function () {});
        }, 800);
        $("header.header").mCustomScrollbar({
            theme: "dark-thin",
            mouseWheelPixels: 80,
            setTop: 0,
            setLeft: 0,
            axis: "y",
            scrollbarPosition: "inside",
            scrollInertia: 200,
            autoDraggerLength: !0,
            alwaysShowScrollbar: 0,
            snapOffset: 0
        });
    });
	
    $('#portfolio').imagesLoaded()
        .progress(function (instance, image) {
            var result = image.isLoaded ? 'loaded' : 'broken';
        });
		
    /*$('#da-thumbs .portfolio-item').each(function () {
        $(this).hoverdir({
            speed: 500,
            easeing: 'ease-in-out',
            hoverDelay: 50,
            inverse: false
        });
    });*/
	
    $(".contact_form").validate();
	
    $('ul.navbar-nav li.nav-item a.nav-link, .home a.btn, .about .btn.my_blog').on('click', function () {
        $('ul.navbar-nav li.nav-item a.nav-link').removeClass('active');
        $(this).addClass('active');
        //var tagid = $(this).attr('href');
        $('.page').removeClass('page-current');
        //$('' + tagid).addClass('page-current');
    });
	
    $('.count-up, .progress-bar .label').each(function () {
        var $this = $(this),
            countTo = $this.attr('data-count');
        $({
            countNum: $this.text()
        });
    });

    var groups = {};
    $('.image-link').each(function () {
        var id = parseInt($(this).attr('data-group'), 9);
        if (!groups[id]) {
            groups[id] = [];
        }
        groups[id].push(this);
    });
    $.each(groups, function () {
        $(this).magnificPopup({
            type: 'image',
            closeOnContentClick: true,
            closeBtnInside: true,
            gallery: {
                enabled: true
            },
            zoom: {
                enabled: true,
                duration: 300
            }
        });
    });

    /*$('.video-link, .map').magnificPopup({
        disableOn: 250,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });*/

    /*$('.portfolio-details').magnificPopup({
        type: 'ajax',
        closeOnContentClick: false,
        closeOnBgClick: false,
        closeBtnInside: true,
        enableEscapeKe: true,
        showCloseBtn: true,
        overflowY: 'auto',
        disableOn: 250
    });*/

    /*$('.filter').isotope({
        itemSelector: '.filter-item',
        stagger: 30,
        transitionDuration: 500
    });*/

    $('.filter-btn').on('click', 'li', function () {
        $('.filter-btn li').removeClass('active');
        $(this).addClass('active');
        var filterValue = $(this).attr('data-filter');
        $('.filter').isotope({
            filter: filterValue,
            animationDuration: 750,
            easing: 'linear'
        });
        $('.filter .filter-item').css({
            position: 'absolute'
        });
    });
    $('.filter .filter-item').css({
        position: 'relative'
    });
    $('#da-thumbs').css({
        height: '100%'
    });

    $('.navbar-toggler').click(function () {
        $('.navbar-collapse').slideToggle(800);
    });

    var form = $('.contact_form'),
        message = $('.contact_msg'),
        form_data;

    function done_func(response) {
        message.fadeIn().removeClass('alert-danger').addClass('alert-success');
        message.text("Thank You!");
        setTimeout(function () {
            message.fadeOut();
        }, 2000);
        form.find('input:not([type="submit"]), textarea').val('');
    }

    function fail_func(data) {
        message.fadeIn().removeClass('alert-success').addClass('alert-success');
        message.text(data.responseText);
        setTimeout(function () {
            message.fadeOut();
        }, 2000);
    }
    form.submit(function (e) {
        e.preventDefault();
        
        if($(".contact_form").validate().errorList.length == 0)
        {
            form_data = $(this).serialize();
            $.ajax({
                    type: 'POST',
                    url: "/wp-content/themes/frans/assets/php/mail.php",
                    data: form_data
                })
                .done(done_func)
                .fail(fail_func);
        }
        
        return false;
    });
});