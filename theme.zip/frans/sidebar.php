<?php if ( is_page( 'about' ) ) : ?>
<section class="about py-100" id="about">
		<div class="container-fluid animated bounceInLeft">
			<div class="row justify-content-center">
				<div class="col-lg-12 col-xl-11">
					<div class="sec-t">
						<h2>About <span>me</span></h2>
					</div>
				</div>
				<div class="col-lg-12 col-xl-11">
					<div class="sub-head">
						<h4><i class="icon-user mr-2"></i>Personal Info</h4>
						<p>

						</p>
					</div>
				</div>

				<div class="col-12"></div>
				<div class="col-md-5 col-xl-5 mb-4 mb-md-0">
					<div class="abut-info">
						<ul class="list-unstyled">
							<li><span class="f_name">First Name</span> : &nbsp Frans</li>
							<li><span class="l_name">Last Name</span> : &nbsp Lourens</li>
							<li><span class="b_date">Date of birth</span> : &nbsp 28 January 1986</li>
							<li><span class="natonality">Nationality</span> : &nbsp South Africa</li>
							<li><span class="freelance">Freelance</span> : &nbsp Available</li>
						</ul>
					</div>
				</div>
				<div class="col-md-6 col-xl-5 offset-md-1">
					<div class="abut-info">
						<ul class="list-unstyled">
							<li><span class="a_p_number">Phone</span> : &nbsp N/A </li>
							<li><span class="a_address">Address</span> : &nbsp Cape Town, South Africa</li>
							<li><span class="a_email">Email</span> : &nbsp N/A </li>
							<li><span class="a_languages">Spoken</span> : &nbsp Afrikaans - English</li>
							<li><span class="a_skype">Skype</span> : &nbsp N/A </li>
						</ul>
					</div>
				</div>
				<div class="col-sm-12 col-xl-11 mt-40">
					<a class="btn btn-brand mr-3" href="#about">Download Resume</a>
					<a class="btn btn-brand-border my_blog" href="#blog">My Blog</a>
				</div>
				<div class="col-12"></div>

				<div class="col-lg-12 col-xl-11 mt-70 fadeInDown slow animated">
					<ul class="list-inline d-flex justify-content-start text-center flex-nowrap">
						<li class="list-inline-item project">
							<i class="icon-briefcase"></i>
							<h4 class="count-up"></h4>
							<h5>Projects Completed</h5>
						</li>
						<li class="list-inline-item project">
							<i class="icon-clock"></i>
							<h4 class="count-up"></h4>
							<h5>Years Experience</h5>
						</li>
						<li class="list-inline-item project">
							<i class="icon-cup"></i>
							<h4 class="count-up"></h4>
							<h5>Happy Customers</h5>
						</li>
						<li class="list-inline-item project">
							<i class="icon-badge"></i>
							<h4 class="count-up"></h4>
							<h5>Winning Awards</h5>
						</li>
					</ul>
				</div>
			</div>
		</div>
</section>
<?php endif; ?>

<?php if ( is_page( 'skills' ) ) : ?>
<section class="skills py-100" id="skills">
	<div class="container-fluid animated bounceInRight">
		<div class="row justify-content-center">
			<div class="col-lg-12 col-xl-11">
				<div class="sec-t">
					<h2>My <span>Skills</span></h2>
				</div>
			</div>
			<div class="col-12"></div>
			<div class="col-lg-12 col-xl-11">
				<div class="sub-head">
					<h4><i class="icon-badge mr-2"></i>Personal Skill</h4>
					<p>Basic Java from school, C# from University, played with swift for IOS for a while (until I discovered React Native)</p>
				</div>
			</div>
			<div class="col-12"></div>
			<div class="col-md-5">
				<div class="skill-item">
					<span class="skill-title">HTML</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 90%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="90">90</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">CSS</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 70%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="70">70</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">Bootstrap</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="60">60</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">PHP</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 85%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="85">85</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">jQuery</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 75%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="75">75</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">Object Oriented Programming</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 75%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="75">75</span></div>
					</div>
				</div>
			</div>
			<div class="col-md-5 offset-md-1">
				<div class="skill-item">
					<span class="skill-title">Wordpress</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="60">60</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">Python</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 70%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="70">70</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">Django</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="60">60</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">React Native</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="50">50</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">Chef</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="60">60</span></div>
					</div>
				</div>
				<div class="skill-item">
					<span class="skill-title">Git</span>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: 70%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="label" data-count="70">70</span></div>
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-xl-11 mb-20">
				<div class="comunicate-skill">
					<div class="sub-head">
						<h4><i class="icon-bubbles mr-2"></i>Communication Skill</h4>
						<p></p>
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-xl-11 fadeInDown slow animated">
				<ul class="list-inline comunicate-skill-items text-center d-flex justify-content-start flex-wrap flex-sm-nowrap">
					<li class="list-inline-item">
						<h5>Afrikaans</h5>
						<div class="comu-icon">
							<i class="fas fa-star"></i>
							<i class="fas fa-star"></i>
							<i class="fas fa-star"></i>
							<i class="fas fa-star"></i>
							<i class="fas fa-star"></i>
						</div>
					</li>
					<li class="list-inline-item">
						<h5>English</h5>
						<div class="comu-icon">
							<i class="fas fa-star"></i>
							<i class="fas fa-star"></i>
							<i class="fas fa-star"></i>
							<i class="fas fa-star"></i>
							<i class="fas fa-star-half-alt"></i>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( is_page( 'experience' ) ) : ?>
<section class="experience py-100" id="experience">
	<div class="container-fluid animated rotateInDownRight">
		<div class="row justify-content-center">
			<div class="col-md-12 col-xl-11">
				<div class="sec-t">
					<h2>My <span>Experience</span></h2>
				</div>
			</div>
			<div class="col-12"></div>

			<div class="col-lg-12 col-xl-11">
				<div class="sub-head">
					<h4><i class="icon-clock mr-2"></i> PERSONAL Experience</h4>
					<p></p>
				</div>
			</div>
			<div class="col-12"></div>

			<div class="col-lg-12 col-xl-5 mb-5 mb-xl-0">
				<ul class="list-unstyled">
					<li class="expe-item">
						<h5><span>Front-End/Back-End Developer - </span>Solutions Today</h5>
						<span class="calendar"><i class="icon-calendar pr-2"></i>2011 - 2012</span>
						<p>Worked with WordPress and php with some mysql development</p>
					</li>
				</ul>
				<ul class="list-unstyled">
					<li class="expe-item">
						<h5><span>Front-End/Back-End Developer - </span>RSAWEB</h5>
						<span class="calendar"><i class="icon-calendar pr-2"></i>2014 - 2019</span>
						<p>PHP/MySQL/Python Developer </p>
						<p>Chef server/Jenkins and Pipeline for instrastructure/code deployment</p>
						<p>Python/Django for service orientated architecture</p>
						<p>Custom PHP Framework, based on Ruby on Rails, used for legacy system</p>
						<p>Build ios/playstore app using React Native</p>
					</li>
				</ul>
			</div>
			<div class="col-lg-12 col-xl-5 offset-xl-1">
				<ul class="list-unstyled">
					<li class="expe-item">
						<h5><span>Front-End/Back-End Developer - </span>Automytest</h5>
						<span class="calendar"><i class="icon-calendar pr-2"></i>2011 - 2014</span>
						<p>Worked on Zend php project with MySQL development and JavaScript/Jquery <br /> moved on to Symfony 2</p>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( is_page( 'education' ) ) : ?>
 <section class="education py-100" id="education">
	 <div class="container-fluid animated rotateInDownLeft">
		 <div class="row justify-content-center">
			 <div class="col-md-12">
				 <div class="sec-t">
					 <h2>Best <span>Education</span></h2>
				 </div>
			 </div>
			 <div class="col-12"></div>

			 <div class="col-lg-12">
				 <div class="sub-head">
					 <h4><i class="icon-graduation mr-2"></i> Educational Background</h4>
					 <p></p>
				 </div>
			 </div>
			 <div class="col-12"></div>

			 <div class="col-lg-12 col-xl-7">
				 <ul class="list-unstyled">
					 <li class="edu-item">
						 <h5><span>BSc Computer Systems -</span>Heriot-Watt University</h5>
						 <span class="calendar"><i class="icon-calendar pr-2"></i>2013 - 2015</span>
						 <p></p>
					 </li>
					 <li class="edu-item">
						 <h5><span>Information Systems Deploma</span> -</span>CTI</h5>
						 <span class="calendar"><i class="icon-calendar pr-2"></i>2009 - 2011</span>
						 <p></p>
					 </li>
				 </ul>
			 </div>
			 <div class="col-lg-5 d-none d-xl-flex justify-content-center align-items-center text-center">
				
			 </div>
		 </div>

	 </div>
 </section>
 <?php endif; ?>

<?php if ( is_page( 'portfolio' ) ) : ?>
	 <section class="portfolio py-100" id="portfolio">
		 <div class="container-fluid animated slideInDown">
			 <div class="row">
				 <div class="col-md-9">
					 <div class="sec-t">
						 <h2>Recent <span>Work</span></h2>
					 </div>
				 </div>
			 </div>

			 <div class="row">
				 <div class="da-thumbs filter" id="da-thumbs">
					 <div class="col-md-8 mb-30 filter-item web">
						 <div class="portfolio-item">
							<a href="https://itunes.apple.com/za/app/rsaweb/id1451459988?mt=8" target="blank" style="text-decoration: underline;">IOS App</a>
							<a href="https://play.google.com/store/apps/details?id=za.co.rsaweb" target="blank" style="text-decoration: underline;">Android App</a>
						 </div>
					 </div>
				 </div>
			 </div>
			 
			<div class="row">
				 <div class="da-thumbs filter" id="da-thumbs">
					 <div class="col-md-10 mb-30 filter-item web">
						 <div class="portfolio-item">
							<a href="https://mobile.myrsaweb.co.za" target="blank" style="text-decoration: underline;">RSAWEB MOBILE DATA</a>
							<a href="https://www.myrsaweb.co.za" target="blank" style="text-decoration: underline;">MyRSAWEB</a>
						 </div>
					 </div>
				 </div>
			 </div>

			 <div class="row">
				 <div class="da-thumbs filter" id="da-thumbs">
					 <div class="col-md-4 mb-30 filter-item web">
						 <div class="portfolio-item">
							<a href="https://metchips.co.za" target="blank" style="text-decoration: underline;">MetChips</a>
						 </div>
					 </div>
				 </div>
			 </div>

		 </div>
	 </section>
 <?php endif; ?>
 
	<?php if ( is_page( 'blog' ) ) : ?>
	 <section class="blog py-100" id="blog">
		 <div class="container-fluid animated slideInUp">
			 <div class="row">
				 <div class="col-md-12">
					 <div class="sec-t">
						 <h2>Latest <span>News</span></h2>
					 </div>
				 </div>
				 <div class="col-12"></div>
				<?php 
				$temp = $wp_query;
				$wp_query= null;
				$wp_query = new WP_Query();
				$wp_query->query('posts_per_page=5' . '&paged='.$paged);
				
				while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
				 <div class="col-md-6 col-lg-4">
					 <div class="blog-item">
						 <div class="blog-text">
							 <a href="<?php the_permalink(); ?>">
								 <h3><?php the_title(); ?></h3>
							 </a>
							 <p><?php the_excerpt(); ?></p>
							 <a href="<?php the_permalink(); ?>">Read More</a>
						 </div>
					 </div>
				 </div>
				<?php endwhile; ?>
			 </div>
		 </div>
	 </section>
 <?php endif; ?>
 
<?php if ( is_page( 'contact' ) ) : ?>
	 <!--Contact section start-->
	 <section class="contact py-100" id="contact">
		 <div class="container-fluid animated rollIn">
			 <div class="row justify-content-center align-items-center">
				 <div class="col-md-12">
					 <div class="sec-t">
						 <h2>Get In <span>Touch</span></h2>
					 </div>
				 </div>
				 <div class="col-12"></div>
				 <!--for divider-->
				 <div class="col-lg-12">
					 <div class="sub-head">
						 <h4><i class="icon-envelope mr-2"></i> Feel free to drop me a line</h4>
						 <p></p>
					 </div>
				 </div>
				 <div class="col-12"></div>
				 <!--for divider-->
				 <div class="col-md-4 mb-5 mb-md-0">
					 <ul class="list-unstyled">
						 <li class="contact-item">
							 <h5>Location</h5>
							 <p class="mb-1"><br>
								 </p>
							 <a href="" class="more-link map">View on Map</a>
						 </li>
						 <li class="contact-item">
							 <h5>Contact</h5>
							 <p> <br> </p>
						 </li>
						 <li class="contact-item">
							 <h5>Support</h5>
							 <!--<a class="more-link" href="/cdn-cgi/l/email-protection#721f131b1e32151f131b1e5c111d1f"><span class="__cf_email__" data-cfemail="d4a7a1a4a4bba6a094a7bda0b1fab7bbb9">[email&#160;protected]</span></a><br>
							 <a class="more-link" href="/cdn-cgi/l/email-protection#422f232b2e02252f232b2e6c212d2f"><span class="__cf_email__" data-cfemail="eb838e879bab98829f8ec5888486">[email&#160;protected]</span></a>-->
						 </li>
						 <li class="contact-item">
							 <h5>Social</h5>
							 <ul class="list-inline mt-3">
								 <!--<li class="list-inline-item mb-2">
									 <a href="#" class="list-inline-link"><i class="icon-social-facebook" title="Facebook"></i></a>
								 </li>
								 <li class="list-inline-item mb-2">
									 <a href="#" class="list-inline-link"><i class="icon-social-twitter" title="Twitter"></i></a>
								 </li>
								 <li class="list-inline-item mb-2">
									 <a href="#" class="list-inline-link"><i class="icon-social-instagram" title="Instagram"></i></a>
								 </li>-->
								 <li class="list-inline-item">
									 <a href="https://www.linkedin.com/in/frans-lourens-28845225/" class="list-inline-link" target="_blank" >LinkedIn</a>
								 </li>
								 <!--<li class="list-inline-item">
									 <a href="#" class="list-inline-link"><i class="icon-social-dribbble" title="Dribbble"></i></a>
								 </li>-->
							 </ul>
						 </li>
					 </ul>
				 </div>
				 <!--col end-->
				 <div class="col-md-7 offset-md-1">
					 <form class="contact_form">
						 <!--form aler message start-->
						 <div class="row">
							 <div class="col-12">
								 <div class="alert alert-success contact_msg" style="display: none" role="alert">
									 Your message was sent successfully.
								 </div>
							 </div>
						 </div>
						 <!--form alert message end-->
						 <!-- Message Input Area Start -->
						 <div class="contact_input_area">
							 <div class="form-group">
								 <i class="icon-user input-icon"></i>
								 <label for="name">
									 <input type="text" name="name" class="form-control" id="name" placeholder="Enter Name" required maxlength="50">
								 </label>
							 </div>
							 <div class="form-group">
								 <i class="icon-envelope input-icon"></i>
								 <label for="email">
									 <input type="email" name="email" class="form-control" placeholder="Your Email" id="email" required maxlength="50">
								 </label>
							 </div>
							 <div class="form-group">
								 <i class="icon-speech input-icon"></i>
								 <label for="subject">
									 <input type="text" class="form-control" placeholder="Enter Subject" id="subject" maxlength="50" name="subject" required>
								 </label>
							 </div>
							 <div class="form-group mb-2">
								 <i class="icon-bubbles input-icon"></i>
								 <label for="message" class="text-area">
									 <textarea class="form-control" name="message" id="message" rows="3" placeholder="Write Message" maxlength="300" required></textarea>
								 </label>
							 </div>
							 <div class="g-recaptcha mb-4" data-sitekey="6LeOUJwUAAAAADsG7Kvs9zSG2pGGa7ux4L-h73nL"></div>
							 <button type="submit" name="submit" class="btn btn-brand2 pull-right" id="btnContactUs">Submit</button>
						 </div>
						 <!-- Message Input Area End -->
					 </form>
				 </div>
			 </div>
			 <!--row end-->
		 </div>
		 <!--container fluid end-->
	 </section>
	 <!--Contact section end-->
<?php endif; ?>