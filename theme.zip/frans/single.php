<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/malihu-scrollbar.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/animate.css">
    <title>Frans Lourens</title>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
  </head>

  <body>
    <header class="header" id="header">
        <nav class="navbar navbar-expand-lg navbar-light p-0">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navmobile" aria-controls="navmobile" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navmobile">
                <ul class="navbar-nav mr-auto flex-column">
                    <li class="nav-item"><a href="/" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="/about/" class="nav-link">About Me</a></li>
                    <li class="nav-item"><a href="/skills/" class="nav-link">Skills</a></li>
                    <li class="nav-item"><a href="/experience/" class="nav-link">Experience</a></li>
                    <li class="nav-item"><a href="/education/" class="nav-link">Education</a></li>
                    <li class="nav-item"><a href="/portfolio/" class="nav-link">Portfolio</a></li>
                    <li class="nav-item"><a href="/blog/" class="nav-link">Blog</a></li>
                    <li class="nav-item"><a href="/contact/" class="nav-link">Contact</a></li>
                </ul>
            </div>
        </nav>

        <!--<div class="contact d-none d-lg-block">
            <div class="contact-item">
                <h5>Company, Inc.</h5>
                <p>
                    123 Evergreen Street <br>
                    San Diego, California
                </p>
            </div>
            <div class="contact-item">
                <h5>Support</h5>
                <a href="/cdn-cgi/l/email-protection#9be2f4eee9f6faf2f7b5f8f4f6"><span class="__cf_email__" data-cfemail="3d4e484d4d524f497d4e544958135e5250">[email&#160;protected]</span></a> <br>
                <a href="/cdn-cgi/l/email-protection#71081e04031c10181d5f121e1c"><span class="__cf_email__" data-cfemail="224a474e5262514b56470c414d4f">[email&#160;protected]</span></a>
            </div>
            <div class="contact-item">
                <h5>Social</h5>
                <ul class="list-inline">
                    <li class="list-inline-item"><a href="#" class="list-inline-link"><i class="icon-social-facebook" title="Facebook"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="list-inline-link"><i class="icon-social-twitter" title="Twitter"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="list-inline-link"><i class="icon-social-instagram" title="Instagram"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="list-inline-link"><i class="icon-social-linkedin" title="Linkedin"></i></a></li>
                </ul>
            </div>
        </div>-->
    </header>
     <main class="wrapper" id="wrapper">
             <?php
             // Start the loop.
             while ( have_posts() ) : the_post();
      
                 /*
                  * Include the post format-specific template for the content. If you want to
                  * use this in a child theme, then include a file called called content-___.php
                  * (where ___ is the post format) and that will be used instead.
                  */
                
              
             ?>
          <section class="blog py-100" id="blog">
                 <div class="container-fluid">
                     <div class="row">
                         <!--blog item-1-->
                         <div class="col-lg-8 mx-auto">
                             <div class="blog-item">
                                 <div class="blog-img">
                                     <!--<img src="assets/img/blgo/blog1.jpg" alt="blog_image" class="img-fluid w-10">-->
                                 </div>
                                 <div class="blog-text">
                                 <h3><?php the_title(); ?></h3>
                                 <?php the_content(); ?>
                                 </div>
                             </div>
     
                             <!--discussion comment setup-->
                             <div class="disqus">
                                 <div id="disqus_thread"></div>
                             </div>
                             <!--discussion comment setup end-->
                         </div>
                     </div>
                 </div>
             </section>
             <!--Blog section end-->
             <?php
             // End the loop.
             endwhile;
             ?>
     </main>
     <?php get_footer(); ?>