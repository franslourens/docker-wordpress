<?php get_header(); ?>
<main class="wrapper" id="wrapper">
	<section class="home page page-current" id="home">
		<div class="container-fluid animated zoomIn">
			<div class="row d-flex align-items-center justify-content-center order-last order-xl-first">
				<div class="col-lg-12 col-xl-6">
					<h5>Hi there! I'm <span>Frans</span></h5>
					<h2 class="pulse animated slower infinite"><span>DevOps</span> Engineer</h2>
					<!--<p class="lead">A successful website does three things: It attracts the right kinds of visitors. Guides them to the main services or product you offer.</p>
					<div class="user-btn">
						<!--<a href="#contact" class="btn btn-brand mr-3">Hire Me</a>
						<a href="/portfolio/" class="btn btn-brand-border">My Portfolio</a>
					</div>-->
                    Currently running on Google Kubernetes Engine (GKE) <br /><br />
                    <p>POD:&nbsp&nbsp&nbsp&nbsp<?php echo getenv("HOSTNAME"); ?></p>
				</div>
			</div>
		</div>
	</section>
<?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>