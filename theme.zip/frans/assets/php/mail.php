<?php
    echo json_encode(array("status" => "ok"));